import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:simplechat/model/post_model.dart';
import 'package:simplechat/model/provider_model.dart';
import 'package:simplechat/pages/otherspages/publication/createPost/spaces_page.dart';
import 'package:simplechat/pages/otherspages/publication/createPost/spaces_params.dart';

class CreatePostMainPage extends StatefulWidget {
  const CreatePostMainPage({super.key});

  @override
  State<CreatePostMainPage> createState() => _CreatePostMainPageState();
}

class _CreatePostMainPageState extends State<CreatePostMainPage> {
  final TextEditingController _postController = TextEditingController();
  XFile? _selectedImage;
  final ImagePicker _picker = ImagePicker();

  Future<void> _pickImage() async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() {
        _selectedImage = image;
      });
    }
  }

  void _submitPost() {
    if (_postController.text.isEmpty && _selectedImage == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Post cannot be empty!")),
      );
      return;
    }

    final newPost = Post(
      text: _postController.text,
      image: _selectedImage != null ? File(_selectedImage!.path) : null,
    );

    Provider.of<PostProvider>(context, listen: false).addPost(newPost);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Post created successfully!")),
    );

    _postController.clear();
    setState(() {
      _selectedImage = null;
    });

    Navigator.pop(context);
  }

  // --- 🔥 Affichage du premier BottomSheet (choix public/private) ---
  void _showDiscussionModal() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
      ),
      builder: (BuildContext context) {
        return Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 5,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                "Start a Discussion",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                "Choose the type of discussion you want to start.",
                style: TextStyle(color: Colors.grey.shade600),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),

              // --- Public Discussion ---
              _buildOptionCard(
                icon: Icons.public,
                title: "Public Discussion",
                subtitle: "Anyone can join and listen",
                color: Colors.deepOrangeAccent.shade100,
                onTap: () {
                  Navigator.pop(context);
                  Future.microtask(() => _showPublicDiscussionModal());
                },
              ),
              const SizedBox(height: 12),

              // --- Private Discussion ---
              _buildOptionCard(
                icon: Icons.lock,
                title: "Private Discussion",
                subtitle: "Only invited people can join",
                color: Colors.pinkAccent.shade100,
                onTap: () {
                  Navigator.pop(context);
                  Future.microtask(() => _showPrivateDiscussionModal());
                },
              ),

              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }

  // --- Modal Public Discussion ---
  void _showPublicDiscussionModal() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        // Controllers pour les champs
        final TextEditingController nameController = TextEditingController();
        double duration = 5; // durée par défaut (en minutes)
        double limit = 10; // nombre de participants par défaut

        return StatefulBuilder(
          builder: (context, setState) => Padding(
            padding: EdgeInsets.only(
              left: 24,
              right: 24,
              top: 16,
              bottom: MediaQuery.of(context).viewInsets.bottom + 24,
            ),
            child: Container(
              width: double.infinity,
              constraints: const BoxConstraints(maxHeight: 600, minHeight: 300),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Petit indicateur de drag
                  Center(
                    child: Container(
                      width: 40,
                      height: 5,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Titre
                  const Center(
                    child: Text(
                      "🎙️ Customize Discussion",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.deepOrange,
                      ),
                    ),
                  ),

                  const SizedBox(height: 25),

                  // Champ Nom du Space
                  const Text(
                    "Space Name",
                    style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: nameController,
                    decoration: InputDecoration(
                      hintText: "Enter the name of your space...",
                      filled: true,
                      fillColor: Colors.grey.shade100,
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 14),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),

                  const SizedBox(height: 25),

                  // Durée par utilisateur
                  const Text(
                    "Duration per Speaker (minutes)",
                    style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: SliderTheme(
                          data: SliderTheme.of(context).copyWith(
                            activeTrackColor: Colors.deepOrange,
                            inactiveTrackColor: Colors.grey.shade300,
                            thumbColor: Colors.deepOrangeAccent,
                            overlayColor: Colors.deepOrange.withOpacity(0.2),
                            trackHeight: 5,
                            valueIndicatorColor:
                                Colors.deepOrangeAccent, // couleur bulle
                            valueIndicatorTextStyle: const TextStyle(
                              color: Colors.white, // texte du label
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          child: Slider(
                            value: duration,
                            min: 1,
                            max: 30,
                            divisions: 29,
                            label: "${duration.toInt()} min",
                            onChanged: (val) => setState(() => duration = val),
                          ),
                        ),
                      ),
                      Text(
                        "${duration.toInt()}m",
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: Colors.deepOrange,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 25),

                  // Nombre limite de participants
                  const Text(
                    "Maximum Participants",
                    style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: SliderTheme(
                          data: SliderTheme.of(context).copyWith(
                            activeTrackColor: Colors.pinkAccent,
                            inactiveTrackColor: Colors.grey.shade300,
                            thumbColor: Colors.pinkAccent,
                            overlayColor: Colors.pinkAccent.withOpacity(0.2),
                            trackHeight: 5,
                            valueIndicatorColor:
                                Colors.pinkAccent, // couleur bulle
                            valueIndicatorTextStyle: const TextStyle(
                              color: Colors.white, // texte du label
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          child: Slider(
                            value: limit,
                            min: 2,
                            max: 1000,
                            divisions: 98,
                            label: "${limit.toInt()} users",
                            onChanged: (val) => setState(() => limit = val),
                          ),
                        ),
                      ),
                      Text(
                        "${limit.toInt()}",
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: Colors.pinkAccent,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 30),

                  // Bouton de validation
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.deepOrange,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        elevation: 2,
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          PageRouteBuilder(
                            pageBuilder:
                                (context, animation, secondaryAnimation) =>
                                    SpacesPage(
                              name: nameController.text,
                              duration: duration,
                              limit: limit,
                            ),
                            transitionsBuilder: (context, animation,
                                secondaryAnimation, child) {
                              const begin = Offset(1.0, 0.0);
                              const end = Offset.zero;
                              const curve = Curves.easeInOut;

                              var tween = Tween(begin: begin, end: end)
                                  .chain(CurveTween(curve: curve));
                              return SlideTransition(
                                position: animation.drive(tween),
                                child: child,
                              );
                            },
                          ),
                        ).then((_) {
                          // Exécuté quand SpacesPage est fermée
                          int count = 0;
                          Navigator.popUntil(context, (route) => count++ == 2);
                        });
                      },
                      child: const Text(
                        "Start Discussion",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // --- Modal Private Discussion ---
  void _showPrivateDiscussionModal() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
      ),
      builder: (context) => Padding(
        padding: const EdgeInsets.all(24.0),
        child: Container(
          width: double.infinity,
          constraints: BoxConstraints(minHeight: 300),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                "Private Discussion",
                style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.pink),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // --- Construction des cartes de choix ---
  Widget _buildOptionCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        //width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.3),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color, width: 1),
        ),
        child: Row(
          children: [
            CircleAvatar(
              radius: 25,
              backgroundColor: color,
              child: Icon(icon, color: Colors.white, size: 28),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      )),
                  const SizedBox(height: 4),
                  Text(subtitle, style: TextStyle(color: Colors.grey.shade700)),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios_rounded,
                size: 18, color: Colors.grey),
          ],
        ),
      ),
    );
  }

  // --- UI principale ---
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text(
          "Create Post",
          style: TextStyle(fontWeight: FontWeight.w600),
        ),
        centerTitle: true,
        backgroundColor: Colors.deepOrangeAccent.shade100,
        elevation: 3,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // --- En-tête ---
            Text(
              "Share your thoughts 💭",
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                color: Colors.grey.shade800,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "Write, add media, or start a live discussion.",
              style: TextStyle(color: Colors.grey.shade600, fontSize: 15),
            ),
            const SizedBox(height: 24),

            // --- Zone de texte stylisée ---
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.shade300,
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: TextField(
                controller: _postController,
                maxLines: 6,
                style: const TextStyle(fontSize: 16),
                decoration: InputDecoration(
                  hintText: "What's on your mind?",
                  hintStyle: TextStyle(color: Colors.grey.shade500),
                  border: InputBorder.none,
                ),
              ),
            ),

            const SizedBox(height: 20),

            // --- Image affichée ---
            if (_selectedImage != null)
              Stack(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: Image.file(
                      File(_selectedImage!.path),
                      width: size.width,
                      height: size.width * 0.55,
                      fit: BoxFit.cover,
                    ),
                  ),
                  Positioned(
                    top: 10,
                    right: 10,
                    child: InkWell(
                      onTap: () {
                        setState(() {
                          _selectedImage = null;
                        });
                      },
                      borderRadius: BorderRadius.circular(20),
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: Colors.black54,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Icon(Icons.close,
                            color: Colors.white, size: 18),
                      ),
                    ),
                  ),
                ],
              ),

            const SizedBox(height: 25),

            // --- Boutons d’action modernisés ---
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _pickImage,
                    icon: const Icon(Icons.image_outlined,
                        color: Colors.deepOrange),
                    label: const Text(
                      "Image",
                      style: TextStyle(
                          color: Colors.deepOrange,
                          fontWeight: FontWeight.w600),
                    ),
                    style: ElevatedButton.styleFrom(
                      elevation: 0,
                      backgroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                        side: const BorderSide(color: Colors.deepOrangeAccent),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.audiotrack_rounded,
                        color: Colors.pinkAccent),
                    label: const Text(
                      "Audio",
                      style: TextStyle(
                          color: Colors.pinkAccent,
                          fontWeight: FontWeight.w600),
                    ),
                    style: ElevatedButton.styleFrom(
                      elevation: 0,
                      backgroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                        side: const BorderSide(color: Colors.pinkAccent),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _submitPost,
                    icon: const Icon(Icons.send_rounded, color: Colors.white),
                    label: const Text(
                      "Post",
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                    style: ElevatedButton.styleFrom(
                      elevation: 2,
                      backgroundColor: Colors.deepOrangeAccent,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 30),
            Divider(color: Colors.grey.shade300, thickness: 1.2),
            const SizedBox(height: 20),

            // --- Discussion Audio Section ---
            Center(
              child: Column(
                children: [
                  Text(
                    "🎙️ Start a live discussion",
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey.shade800,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    "Host a live audio conversation with your followers.",
                    style: TextStyle(color: Colors.grey.shade600),
                  ),
                  const SizedBox(height: 25),
                  Hero(
                    tag: "micHero",
                    child: Image.asset(
                      "assets/images/mic.png",
                      width: 160,
                      height: 160,
                    ),
                  ),
                  const SizedBox(height: 25),
                  InkWell(
                    onTap: _showDiscussionModal,
                    borderRadius: BorderRadius.circular(50),
                    child: Container(
                      width: 180,
                      height: 50,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(50),
                        gradient: const LinearGradient(
                          colors: [Colors.deepOrangeAccent, Colors.pinkAccent],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.pinkAccent.withOpacity(0.3),
                            blurRadius: 10,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: const Center(
                        child: Text(
                          "Start Now",
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
